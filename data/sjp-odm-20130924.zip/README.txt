
S�ownik SJP.pl - wersja: odmiany s��w

---

S�ownik udost�pniany jest na licencjach GPL, LGPL oraz
Creative Commons ShareAlike (http://creativecommons.org/licenses/sa/1.0)

Najnowsza wersja s�ownika do pobrania ze strony:
http://www.sjp.pl/

